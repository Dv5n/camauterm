import subprocess

print ("Free And Open Source. Should not be sold.")
print ("You have been warned.\n")

subprocess.call(["python", "camau.py"])
