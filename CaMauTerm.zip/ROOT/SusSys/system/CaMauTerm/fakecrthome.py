## This DOESN'T create the user folder
sname = input("Enter a Cool Name: ")
print("Ok, Not Created User: " + sname)
